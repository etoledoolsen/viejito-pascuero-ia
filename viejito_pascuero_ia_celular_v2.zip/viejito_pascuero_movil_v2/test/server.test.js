'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const {spawn}=require('node:child_process');const net=require('node:net');
const {sanitize,promptFor,sessionFor}=require('../server.js');

test('sanitize elimina caracteres de control y trunca',()=>{
  assert.equal(sanitize('  Ana\n<mal>  ',8),'Ana mal');
  assert.equal(sanitize('abcdefgh',3),'abc');
});
test('prompt infantil seguro y configuración de audio',()=>{
  const s=promptFor({name:'Jacinta',age:'2',likes:'unicornios'});
  assert.match(s,/Jacinta/);assert.match(s,/unicornios/);assert.match(s,/No pidas apellidos/);
  const config=sessionFor({name:'Jacinta',age:'2',likes:'unicornios'});
  assert.equal(config.session.type,'realtime');
  assert.equal(config.session.audio.input.turn_detection.type,'server_vad');
});
async function freePort(){return await new Promise((resolve,reject)=>{const srv=net.createServer();srv.listen(0,'127.0.0.1',()=>{const port=srv.address().port;srv.close(()=>resolve(port));});srv.on('error',reject);});}
async function startServer(extra={}){
  const port=await freePort();const child=spawn(process.execPath,['server.js'],{cwd:require('node:path').resolve(__dirname,'..'),env:{...process.env,PORT:String(port),HOST:'127.0.0.1',OPENAI_API_KEY:'',FAMILY_PASSWORD:'clave-familiar-muy-segura',...extra},stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',x=>stderr+=x);
  const base=`http://127.0.0.1:${port}`;
  for(let i=0;i<60;i++){
    if(child.exitCode!==null)throw new Error('Servidor falló '+stderr);
    try{const r=await fetch(base+'/health');if(r.ok)return {child,base};}catch{}
    await new Promise(r=>setTimeout(r,40));
  }
  child.kill();throw new Error('No inició servidor '+stderr);
}
async function closeServer(s){s.child.kill();await new Promise(r=>{if(s.child.exitCode!==null)return r();s.child.once('exit',r);});}
test('login privado, archivos bloqueados, modo demo y cierre de sesión',async()=>{
  const srv=await startServer();
  try{
    let r=await fetch(srv.base+'/',{redirect:'manual'});assert.equal(r.status,302);assert.equal(r.headers.get('location'),'/login.html');
    r=await fetch(srv.base+'/assets/santa.webp',{redirect:'manual'});assert.equal(r.status,302);
    r=await fetch(srv.base+'/login.html');assert.equal(r.status,200);
    r=await fetch(srv.base+'/style.css');assert.equal(r.status,200);
    r=await fetch(srv.base+'/api/config');assert.equal(r.status,401);
    r=await fetch(srv.base+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:'no'})});assert.equal(r.status,401);
    r=await fetch(srv.base+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:'clave-familiar-muy-segura'})});assert.equal(r.status,200);
    const cookie=r.headers.get('set-cookie').split(';')[0];assert.match(cookie,/santa_session/);
    r=await fetch(srv.base+'/',{headers:{Cookie:cookie}});assert.equal(r.status,200);assert.match(await r.text(),/¡Habla con Santa!/);
    r=await fetch(srv.base+'/api/config',{headers:{Cookie:cookie}});assert.equal(r.status,200);const config=await r.json();assert.equal(config.online,false);
    r=await fetch(srv.base+'/api/session',{method:'POST',headers:{Cookie:cookie,'Content-Type':'application/json'},body:'{}'});assert.equal(r.status,400);
    r=await fetch(srv.base+'/api/logout',{method:'POST',headers:{Cookie:cookie}});assert.equal(r.status,200);assert.match(r.headers.get('set-cookie'),/Max-Age=0/);
    r=await fetch(srv.base+'/api/session',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});assert.equal(r.status,401);
  }finally{await closeServer(srv);}
});
test('el backend solicita token efímero a OpenAI (upstream simulado)',async()=>{
  const port=await freePort();
  const code=`
  const assert=require('node:assert/strict');
  global.fetch=async (url,opt)=>{
    assert.equal(String(url),'https://api.openai.com/v1/realtime/client_secrets');
    assert.match(opt.headers.Authorization,/Bearer sk-test-/);
    const p=JSON.parse(opt.body);
    assert.equal(p.session.type,'realtime');
    assert.match(p.session.instructions,/Jacinta/);
    return {ok:true,status:200,json:async()=>({value:'ek_mock_token'})};
  };
  require('./server.js').makeServer().listen(process.env.PORT,'127.0.0.1');`;
  const child=spawn(process.execPath,['-e',code],{cwd:require('node:path').resolve(__dirname,'..'),env:{...process.env,OPENAI_API_KEY:'sk-test-unit',FAMILY_PASSWORD:'clave-familiar-muy-segura',PORT:String(port)},stdio:'ignore'});
  const base=`http://127.0.0.1:${port}`;
  try{
    let ready=false;
    for(let i=0;i<50;i++){try{const r=await fetch(base+'/health');if(r.ok){ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,40));}
    assert.ok(ready,'arrancó el servidor simulado');
    let r=await fetch(base+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:'clave-familiar-muy-segura'})});
    assert.equal(r.status,200);const cookie=r.headers.get('set-cookie').split(';')[0];
    r=await fetch(base+'/api/session',{method:'POST',headers:{Cookie:cookie,'Content-Type':'application/json'},body:JSON.stringify({name:'Jacinta',age:'2',likes:'unicornios'})});
    assert.equal(r.status,200);assert.deepEqual(await r.json(),{value:'ek_mock_token'});
  }finally{child.kill();await new Promise(resolve=>{if(child.exitCode!==null)return resolve();child.once('exit',resolve);});}
});
