'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const el = {
    name:$('childName'), age:$('childAge'), likes:$('childLikes'),
    adult:$('adultCheck'), demo:$('forceDemo'), demoLabel:$('demoLabel'),
    call:$('callBtn'), hang:$('hangBtn'), mute:$('muteBtn'), listen:$('listenBtn'), sound:$('soundBtn'),
    timer:$('callTimer'), speech:$('speech'), badge:$('connectionBadge'),
    santa:$('santaWrap'), note:$('modeNote'), audio:$('remoteAudio'), config:$('configFields')
  };
  const state = {
    online:false, active:false, connecting:false, mode:'demo', pc:null, dc:null,
    localStream:null, recognition:null, recognizing:false, speaking:false, audioText:'',
    timerInterval:null, startedAt:0, maxMinutes:6, generation:0, muted:false
  };
  const maxMs = () => state.maxMinutes * 60 * 1000;
  const profile = () => ({name:el.name.value.trim()||'amiguito',age:el.age.value,likes:el.likes.value.trim()});
  const setBadge = (text, type='') => {el.badge.textContent=text;el.badge.className=`status-badge ${type}`;};
  const say = (text,talking=false) => {el.speech.textContent=text; state.speaking=talking;el.santa.classList.toggle('talking',talking);el.santa.classList.remove('listening');};
  const busy = v => {
    el.call.disabled=v;el.hang.disabled=!v;
    el.mute.disabled=!v||state.mode!=='ai';
    el.listen.disabled=!v||state.mode!=='demo';
    el.demo.disabled=v;el.adult.disabled=v;
    el.config.querySelectorAll('input,select').forEach(input=>input.disabled=v);
  };
  const formatTime = s => `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;
  function startTimer(){
    state.startedAt=Date.now();
    clearInterval(state.timerInterval);
    state.timerInterval=setInterval(() => {
      const s=Math.max(0,Math.floor((Date.now()-state.startedAt)/1000));
      el.timer.textContent=`${formatTime(Math.min(s,maxMs()/1000))} / ${formatTime(maxMs()/1000)}`;
      if(s*1000>=maxMs()){stopCall('¡Se acabó el ratito! ¡Hasta la próxima! 🎄');setBadge('Llamada finalizada');}
    },1000);
  }
  function stopCall(message='¡Hasta pronto! ¡Jo, jo, jo! 🎄'){
    state.active=false;state.connecting=false;state.generation++;
    clearInterval(state.timerInterval);state.timerInterval=null;
    try{speechSynthesis.cancel();}catch{}
    try{state.recognition?.abort();}catch{}
    state.recognition=null;state.recognizing=false;
    try{state.dc?.close();}catch{}
    try{state.pc?.close();}catch{}
    try{state.localStream?.getTracks().forEach(t=>t.stop());}catch{}
    try{el.audio.pause();el.audio.srcObject=null;}catch{}
    state.dc=null;state.pc=null;state.localStream=null;state.muted=false;
    el.mute.textContent='🎤 Micrófono activo';el.sound.hidden=true;
    say(message,false);setBadge('Preparado');busy(false);
    el.timer.textContent=`00:00 / ${formatTime(maxMs()/1000)}`;
  }
  async function loadMode(){
    try{
      const r=await fetch('/api/config',{cache:'no-store'});
      if(r.status===401){location.assign('/login.html');return;}
      if(!r.ok)throw new Error('No se pudo consultar el servidor');
      const config=await r.json();state.online=Boolean(config.online);state.maxMinutes=Number(config.maxMinutes||6);
      el.timer.textContent=`00:00 / ${formatTime(maxMs()/1000)}`;
      el.demoLabel.hidden=!state.online;
      el.note.textContent=state.online?'✨ IA por voz disponible. Conecta el micrófono y Santa podrá responder libremente.':'🎁 Demostración sin costos: cuentos y juegos preparados. Para hablar libremente configura OPENAI_API_KEY.';
    }catch{el.note.textContent='No se pudo consultar la IA. Puedes seguir jugando en modo demostración.';state.online=false;el.demoLabel.hidden=true;}
  }
  function sendEvent(payload){if(state.dc?.readyState!=='open')return false;state.dc.send(JSON.stringify(payload));return true;}
  function remoteMessage(event){
    let msg;try{msg=JSON.parse(event.data);}catch{return;}
    const t=msg.type||'';
    if(t==='input_audio_buffer.speech_started'){
      el.santa.classList.remove('talking');el.santa.classList.add('listening');
      setBadge('Te escucho','live');
    }
    if(t==='response.created'){
      state.audioText='';say('Santa está pensando qué decir…',true);setBadge('Santa responde','busy');
    }
    if(t==='output_audio_buffer.started'){el.santa.classList.add('talking');el.santa.classList.remove('listening');setBadge('Santa está hablando','busy');}
    if(t==='response.output_audio_transcript.delta'||t==='response.output_text.delta'){
      if(typeof msg.delta==='string'){
        state.audioText+=msg.delta;
        say(state.audioText.slice(-400),true);
      }
    }
    if(t==='response.output_audio_transcript.done'&&msg.transcript) say(String(msg.transcript).slice(-400),true);
    if(t==='response.output_text.done'&&msg.text) say(String(msg.text).slice(-400),true);
    if(t==='output_audio_buffer.stopped'||t==='response.done'){
      el.santa.classList.remove('talking');setBadge('Te escucho','live');
    }
    if(t==='error'){
      console.warn('Error de llamada: ',msg.error?.code||'unknown');
      setBadge('Error temporal','busy');
      el.note.textContent='La IA informó un problema. Puedes colgar y volver a llamar.';
    }
  }
  async function startAI(){
    state.active=true;state.connecting=true;state.mode='ai';state.muted=false;
    busy(true);setBadge('Conectando…','busy');say('¡Un momento! Estoy llamando al Polo Norte…');
    const thisCall=++state.generation;
    try{
      if(!window.isSecureContext||!navigator.mediaDevices?.getUserMedia){throw new Error('Abre esta aplicación mediante HTTPS para usar el micrófono en el celular.');}
      const stream=await navigator.mediaDevices.getUserMedia({video:false,audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
      if(thisCall!==state.generation){stream.getTracks().forEach(t=>t.stop());return;}
      state.localStream=stream;
      const res=await fetch('/api/session',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(profile()),cache:'no-store'});
      const j=await res.json();
      if(res.status===401){stopCall();location.assign('/login.html');return;}
      if(!res.ok)throw new Error(j.error||'No se pudo conectar con OpenAI.');
      if(!j.value)throw new Error('No recibimos credencial temporal de la IA.');
      if(thisCall!==state.generation)return;
      const pc=new RTCPeerConnection();state.pc=pc;
      for(const track of stream.getAudioTracks())pc.addTrack(track,stream);
      pc.ontrack = ev => {
        if(thisCall!==state.generation)return;
        el.audio.srcObject=ev.streams[0]||new MediaStream([ev.track]);
        el.audio.play().then(()=>el.sound.hidden=true).catch(()=>{el.sound.hidden=false;el.note.textContent='Presiona «Activar sonido» para escuchar al Viejito Pascuero.';});
      };
      pc.onconnectionstatechange = () => {
        if(thisCall!==state.generation)return;
        if(pc.connectionState==='failed'||pc.connectionState==='closed'){
          if(state.active){stopCall('Se cortó la llamada. Puedes intentarlo otra vez.');setBadge('Sin conexión','busy');}
        }
      };
      const dc=pc.createDataChannel('oai-events');state.dc=dc;
      dc.onopen = () => {
        if(thisCall!==state.generation)return;
        state.connecting=false;setBadge('Conectado','live');startTimer();
        say('¡Jo, jo, jo! Santa te está saludando…',true);
        sendEvent({type:'response.create',response:{instructions:`Saluda a ${profile().name} con mucho cariño en español de Chile. Di una frase muy corta y una sola pregunta divertida.`}});
      };
      dc.onmessage=remoteMessage;
      const offer=await pc.createOffer();await pc.setLocalDescription(offer);
      const sdpResponse=await fetch('https://api.openai.com/v1/realtime/calls',{
        method:'POST',body:offer.sdp,headers:{'Authorization':`Bearer ${j.value}`,'Content-Type':'application/sdp'}
      });
      if(!sdpResponse.ok)throw new Error(`No se completó la llamada de voz (${sdpResponse.status}). Revisa el modelo y el acceso a la API.`);
      if(thisCall!==state.generation)return;
      await pc.setRemoteDescription({type:'answer',sdp:await sdpResponse.text()});
    }catch(error){
      if(thisCall!==state.generation)return;
      console.error(error);
      stopCall('No pude conectarme. Probemos de nuevo.');
      setBadge('No conectado','busy');el.note.textContent=`⚠️ ${error.message}`;
    }
  }
  let demoTopic='animales';const demoIndex={};
  const demoLines={
    animales:['¡Muuu! ¿Sabes qué sonido hace una vaca?','¡Guau guau! ¿Y el perrito cómo hace?','¡Miau! ¡Qué lindo gato! ¿Tienes un animal favorito?'],
    unicornio:['¡Jo, jo, jo! ¡Me encantan los unicornios! ¿De qué color es el tuyo?','Tengo uno que se llama Estrellita. ¿Cómo llamarías al tuyo?'],
    colores:['¡Jugamos a los colores! Mi traje es rojo. ¿Cuál es tu color favorito?','¡Qué bonito color! ¿Puedes buscar algo azul?'],
    cuento:['Había una vez un renito pequeño que encontró una estrella bajo la nieve. Se la regaló a su amigo y los dos se pusieron a bailar. ¡Fin! ¿Te gustó?'],
    general:['¡Qué alegría escucharte! ¿Te gustan los animales?','¡Jo, jo, jo! ¿Quieres que juguemos con colores?']
  };
  function demoAnswer(input){
    const s=String(input||'').toLowerCase();
    if(/chao|adios|chau/.test(s))return `¡Chao, ${profile().name}! ¡Te mando un abrazo gigante!`;
    if(/unicorn/.test(s))demoTopic='unicornio';
    else if(/cuento|historia/.test(s))demoTopic='cuento';
    else if(/animal|vaca|gato|perro|muu|guau|miau/.test(s))demoTopic='animales';
    else if(/color|azul|rojo|verde|rosad|rosa|amarill/.test(s))demoTopic='colores';
    const arr=demoLines[demoTopic]||demoLines.general;
    const i=demoIndex[demoTopic]||0;demoIndex[demoTopic]=i+1;
    return arr[i%arr.length];
  }
  function chooseVoice(){
    const voices=window.speechSynthesis?.getVoices()||[];
    return voices.find(v=>v.lang.toLowerCase()==='es-cl'&&/male|hombre|jorge|pablo|diego/i.test(v.name))
      ||voices.find(v=>v.lang.toLowerCase()==='es-cl')
      ||voices.find(v=>v.lang.toLowerCase().startsWith('es-'))||null;
  }
  function speakDemo(text){
    if(!state.active||state.mode!=='demo')return;
    try{speechSynthesis.cancel();}catch{}
    try{state.recognition?.abort();}catch{}
    state.recognizing=false;
    const thisCall=state.generation;
    say(text,true);setBadge('Santa habla','busy');
    if(!('speechSynthesis' in window)){say(text,false);setBadge('Toca un juego','live');return;}
    const u=new SpeechSynthesisUtterance(text);u.lang='es-CL';u.rate=.84;u.pitch=.79;
    const voice=chooseVoice();if(voice)u.voice=voice;
    u.onend=()=>{
      if(thisCall!==state.generation||!state.active)return;
      say(text,false);setBadge('Te escucho','live');listenDemo(false);
    };
    u.onerror=()=>{
      if(thisCall!==state.generation||!state.active)return;
      say(text,false);setBadge('Toca un juego','live');
    };
    speechSynthesis.speak(u);
  }
  function listenDemo(manual){
    if(!state.active||state.mode!=='demo'||state.speaking||state.recognizing)return;
    const Rec=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!Rec){el.note.textContent='En este navegador el reconocimiento de voz no está disponible. Puedes usar los botones de juegos.';return;}
    try{
      const recognition=new Rec();state.recognition=recognition;
      recognition.lang='es-CL';recognition.interimResults=false;recognition.continuous=false;
      recognition.onstart=()=>{state.recognizing=true;setBadge('Te escucho','live');el.santa.classList.add('listening');};
      recognition.onresult=e=>{const text=e.results?.[0]?.[0]?.transcript||'';state.recognizing=false;el.santa.classList.remove('listening');if(state.active)speakDemo(demoAnswer(text));};
      recognition.onerror=e=>{state.recognizing=false;el.santa.classList.remove('listening');if(state.active){el.note.textContent=e.error==='not-allowed'?'Permite acceso al micrófono desde el navegador.':'Puedes usar los juegos o tocar «Escucharme» otra vez.';}};
      recognition.onend=()=>{state.recognizing=false;el.santa.classList.remove('listening');};
      recognition.start();
    }catch{if(manual)el.note.textContent='El navegador no pudo iniciar el micrófono. Usa los botones de juegos.';}
  }
  function startDemo(){
    state.active=true;state.mode='demo';state.connecting=false;state.generation++;
    busy(true);el.mute.disabled=true;el.listen.disabled=false;startTimer();
    el.note.textContent='🎁 Modo demostración: las respuestas son preprogramadas y la voz depende del navegador.';
    speakDemo(`¡Jo, jo, jo! ¡Hola, ${profile().name}! Soy el Viejito Pascuero. ¿Te gustan los unicornios?`);
  }
  async function startCall(){
    if(state.active||state.connecting)return;
    if(!el.adult.checked){el.note.textContent='Para iniciar, un adulto debe confirmar que acompañará al niño.';el.adult.focus();return;}
    if(state.online&&!el.demo.checked)await startAI();else startDemo();
  }
  function topicClick(topic){
    if(!state.active){say('¡Primero toca «Llamar a Santa»! 🎅');return;}
    demoTopic=topic;
    if(state.mode==='demo')return speakDemo(demoAnswer(topic));
    if(state.dc?.readyState!=='open'){el.note.textContent='La llamada todavía se está conectando.';return;}
    sendEvent({type:'conversation.item.create',item:{type:'message',role:'user',content:[{type:'input_text',text:`El adulto eligió ${topic}. Propón ahora un juego o cuento muy breve sobre ${topic} y una sola pregunta.`}]}});
    sendEvent({type:'response.create'});
  }
  el.call.addEventListener('click',startCall);
  el.hang.addEventListener('click',()=>stopCall());
  el.mute.addEventListener('click',()=>{
    if(state.mode!=='ai'||!state.localStream)return;
    state.muted=!state.muted;
    state.localStream.getAudioTracks().forEach(t=>t.enabled=!state.muted);
    el.mute.textContent=state.muted?'🔇 Micrófono silenciado':'🎤 Micrófono activo';
  });
  el.listen.addEventListener('click',()=>listenDemo(true));
  el.sound.addEventListener('click',()=>el.audio.play().then(()=>{el.sound.hidden=true;}).catch(()=>{el.note.textContent='Sube el volumen multimedia del celular y vuelve a tocar.';}));
  document.querySelectorAll('[data-topic]').forEach(btn=>btn.addEventListener('click',()=>topicClick(btn.dataset.topic)));
  $('logout').addEventListener('click',async()=>{stopCall();await fetch('/api/logout',{method:'POST'}).catch(()=>{});location.assign('/login.html');});
  window.addEventListener('pagehide',()=>{if(state.active)stopCall();});
  if('serviceWorker' in navigator && window.isSecureContext) navigator.serviceWorker.register('/sw.js').catch(()=>{});
  loadMode();
})();
