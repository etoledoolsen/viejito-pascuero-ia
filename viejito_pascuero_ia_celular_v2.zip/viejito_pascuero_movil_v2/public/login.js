'use strict';
document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const button=document.getElementById('loginBtn');
  const msg=document.getElementById('loginMessage');
  button.disabled=true;msg.textContent='Verificando…';
  try {
    const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:document.getElementById('password').value})});
    const j=await r.json();
    if(!r.ok)throw new Error(j.error||'No se pudo acceder');
    location.assign('/');
  }catch(err){msg.textContent=err.message;button.disabled=false;}
});
