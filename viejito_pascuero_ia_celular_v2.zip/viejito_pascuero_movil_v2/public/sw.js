// SW mínimo: permite instalación PWA sin guardar grabaciones, páginas privadas ni credenciales.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
